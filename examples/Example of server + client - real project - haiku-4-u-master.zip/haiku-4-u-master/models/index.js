module.exports = {
  Haikus: require("./Haikus"),
};
